package com.example.twoAmAutoDrive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwoAmAutoDriveApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwoAmAutoDriveApplication.class, args);
	}

}
