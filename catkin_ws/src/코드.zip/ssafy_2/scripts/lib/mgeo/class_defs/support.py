supported_class = {
    'synced_signal' : True,
    'intersection_controller' : True,
    'mscenario' : True,
    'openscenario' : True
}